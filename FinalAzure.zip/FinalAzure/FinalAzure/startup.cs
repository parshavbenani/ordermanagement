﻿using FinalAzure.DataAccess.Data;
using FinalAzure.DataAccess.IRepository;
using FinalAzure.DataAccess.Repository;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

[assembly: FunctionsStartup(typeof(FinalAzure.startup))]
namespace FinalAzure
{
    public class startup : FunctionsStartup
    {
         public override void Configure(IFunctionsHostBuilder builder)
      {
        var connectionString = Environment.GetEnvironmentVariable("con").ToString();
        builder.Services.AddDbContext<ApplicationDbContext>(
            options => options.UseMySql(connectionString, ServerVersion.AutoDetect(connectionString))
        );
        builder.Services.AddScoped<IAddress, AddressRepository>();
        builder.Services.AddScoped<IOrder, OrderRepository>();
       // builder.Services.AddScoped<IUsers, UserRepository>();
        builder.Services.AddScoped<IProducts, ProductRepository>();

       
       }
    }
}
