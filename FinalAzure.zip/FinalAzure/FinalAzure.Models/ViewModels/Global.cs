﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalAzure.Models.ViewModels
{
    public class Global
    {
        public enum status
        {
            Open = 1,
            Draft = 2,
            Shipped = 3,
            Paid = 4
        }

        public enum AddressType
        {
            Shipping = 1,
            Billing = 2
        }

    }
}
