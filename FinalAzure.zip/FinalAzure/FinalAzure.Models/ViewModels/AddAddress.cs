﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalAzure.Models.ViewModels
{
    public class AddAddressViewModel
    {
        [Required]
        public string HouseNo { get; set; }
        [Required]
        public string Country { get; set; }
        [Required]
        public string State { get; set; }
        [Required]
        public string City { get; set; }
        [MaxLength(6), Required]
        public string ZipCode { get; set; }
        [Required]
        public string ContactPerson { get; set; }
        [MinLength(10), MaxLength(10), Required]
        public string ContactNo { get; set; }
        [ForeignKey("aspnetusers")]
        public string? userId { get; set; }
        [Required]
        public Global.AddressType AddressType { get; set; }
        [Required]
        public string ContactEmail { get; set; }
    }
}
