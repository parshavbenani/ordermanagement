﻿using FinalAzure.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalAzure.DataAccess.IRepository
{
    public interface IProducts
    {
        public Task<response> GetProductsList();
        public Task<response> GetProducts(int Id);
    }
}
