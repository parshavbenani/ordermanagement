﻿using DataModels.Models;
using DataModels.Models.GetModel;
using Models.Models.GetModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Repository.IRepository
{
    public interface IOrderRepository
    {
        public Task<Response> Get(OrderSearchModel model);
        public Task<Response> AddOrder(OrderPostModel order);

        public Task<Response> UpdateOrderStatus(int orderId, int StatusId);
    }
}
