﻿using DataModels.Models;
using DataModels.Models.GetModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Repository.IRepository
{
    public interface IAddressRepository
    {
        public Task<Response> AddAddress(AddressGetModel model);

        public Task<Response> GetAddressList(string email);

        public Task<Response> UpdateAddress(UpdateAddressModel model);
    }
}
