﻿using DataAccess.Data;
using DataAccess.Repository.IRepository;
using DataModels.Models;
using DataModels.Models.GetModel;
using Microsoft.EntityFrameworkCore;
using static DataModels.ViewModels.Constants;

namespace DataAccess.Repository
{
    public class AddressRepository : IAddressRepository
    {
        #region Constructor
        private ApplicationDbContext _db;

        public AddressRepository(ApplicationDbContext db)
        {
            _db = db;

        }
        #endregion
        
        #region Add Address
        public async Task<Response> AddAddress(AddressGetModel model)
        {
            Response response = new Response();


            try
            {
                var user = _db.aspnetusers.Where(x => x.Id == model.UserId).FirstOrDefault();
                if (user != null)
                {
                    #region Shipping Address
                    if (model.UserId != null && model.AddressType == (int)AddressTypes.Shipping)
                    {
                        Address objAddress = new Address()
                        {
                            AddressType = AddressTypes.Shipping,
                            BuildingOrFlatNo = model.BuildingOrFlatNo,
                            Country = model.Country,
                            State = model.State,
                            City = model.City,
                            ZipCode = model.ZipCode,
                            ContactPerson = model.ContactPerson,
                            ContactNo = model.ContactNo,
                            Email = model.Email,
                            UserId = user.Id
                        };

                        _db.addressestwo.Add(objAddress);
                        _db.SaveChanges();

                        response.Status = "200 Ok";
                        response.Message = "Shipping Address Added";
                        response.Data = "";

                        return response;

                    }
                    #endregion

                    #region Billing Address
                    else if (model.UserId != null && model.AddressType == (int)AddressTypes.Billing)
                    {
                        var userAddress = await _db.addressestwo.Where(x => x.UserId == model.UserId && x.AddressType == AddressTypes.Billing).FirstOrDefaultAsync();
                        if (userAddress != null)
                        {
                            response.Status = "500 Bad";
                            response.Message = "You cannot add another billing address";
                            response.Data = "";

                            return response;
                        }
                        else
                        {
                            Address objAddress = new Address()
                            {
                                AddressType = AddressTypes.Billing,
                                BuildingOrFlatNo = model.BuildingOrFlatNo,
                                Country = model.Country,
                                State = model.State,
                                City = model.City,
                                ZipCode = model.ZipCode,
                                ContactPerson = model.ContactPerson,
                                ContactNo = model.ContactNo,
                                Email = model.Email,
                                UserId = user.Id
                            };
                            _db.addressestwo.Add(objAddress);
                            _db.SaveChanges();
                            response.Status = "200 Ok";
                            response.Message = "Billing Address Added";
                            response.Data = "";

                            return response;
                        }
                    }
                    #endregion

                }
                else
                {
                    response.Status = "500 Bad";
                    response.Message = "User Not Exist";
                    response.Data = "";
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }

            response.Status = "500 Bad";
            response.Message = "Something Went Wrong";
            response.Data = "";

            return response;
        }
        #endregion

        #region Get Address
        public async Task<Response> GetAddressList(string email)
        {
            Response response= new Response();

            try
            {
                List<Address> addresses = new List<Address>();

                var userAdd = await _db.addressestwo.Where(z => z.Email == email).ToListAsync();
                if(userAdd.Any())
                {
                    foreach (var item in userAdd)
                    {
                        addresses.Add(item);
                    }
                    response.Status = "200 Ok";
                    response.Message = "success";
                    response.Data = addresses;

                    return response;
                }
                else
                {
                    response.Status = "500 bad";
                    response.Message = "Address not found";
                    response.Data = "";

                    return response;
                }
                

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            response.Status = "500 bad";
            response.Message = "Something Went Wrong";
            response.Data = "";

            return response;
        }
        #endregion

        #region Update OrderAddress
        public async Task<Response> UpdateAddress(UpdateAddressModel model)
        {
            Response response = new Response();

            try
            {
                var orderAddress = _db.orderaddress.Where(x => x.OrderAddId == model.OrderAddressId).FirstOrDefault();
                if (orderAddress != null)
                {
                    //Update Shipping
                    if (model.AddressType == AddressTypes.Shipping)
                    {
                        var objAddress = _db.addressestwo.Where(x => x.AddressId == orderAddress.ShippingAddress).FirstOrDefault();
                        if (objAddress != null)
                        {

                            objAddress.AddressType = AddressTypes.Shipping;
                            objAddress.BuildingOrFlatNo = model.Address.BuildingOrFlatNo;
                            objAddress.Country = model.Address.Country;
                            objAddress.State = model.Address.State;
                            objAddress.City = model.Address.City;
                            objAddress.ZipCode = model.Address.ZipCode;
                            objAddress.ContactPerson = model.Address.ContactPerson;
                            objAddress.ContactNo = model.Address.ContactNo;
                            objAddress.Email = model.Address.Email;
                            objAddress.UserId = model.Address.UserId;

                            _db.addressestwo.Update(objAddress);
                            _db.SaveChanges();

                            response.Status = "200 Ok";
                            response.Message = "Success";
                            response.Data = "";

                            return response;

                        }
                    }

                    //Update Billing
                    else if (model.AddressType == AddressTypes.Billing)
                    {
                        var objAddress = _db.addressestwo.Where(x => x.AddressId == orderAddress.BillingAddress).FirstOrDefault();
                        if (objAddress != null)
                        {
                            objAddress.AddressType = AddressTypes.Billing;
                            objAddress.BuildingOrFlatNo = model.Address.BuildingOrFlatNo;
                            objAddress.Country = model.Address.Country;
                            objAddress.State = model.Address.State;
                            objAddress.City = model.Address.City;
                            objAddress.ZipCode = model.Address.ZipCode;
                            objAddress.ContactPerson = model.Address.ContactPerson;
                            objAddress.ContactNo = model.Address.ContactNo;
                            objAddress.Email = model.Address.Email;
                            objAddress.UserId = model.Address.UserId;

                            _db.addressestwo.Update(objAddress);
                            _db.SaveChanges();

                            response.Status = "200 Ok";
                            response.Message = "Success";
                            response.Data = "";

                            return response;
                        }
                    }
                }
                else
                {
                    response.Status = "500 Bad";
                    response.Message = "Order Address Id not exist";
                    response.Data = "";

                    return response;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            response.Status = "500 Bad";
            response.Message = "Something Went Wrong";
            response.Data = "";

            return response;
        } 
        #endregion
    }
}
