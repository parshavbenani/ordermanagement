﻿using DataAccess.Data;
using DataAccess.Repository.IRepository;
using DataModels.Models;
using DataModels.Models.GetModel;
using Microsoft.AspNetCore.Http.Internal;
using Microsoft.EntityFrameworkCore;
using Models.Models.GetModel;
using static DataModels.ViewModels.Constants;

namespace DataAccess.Repository
{
    public class OrderRepository : IOrderRepository
    {
        #region Constructor
        private ApplicationDbContext _db;

        public OrderRepository(ApplicationDbContext db)
        {
            _db = db;

        }
        #endregion

        #region Add Draft Order
        public async Task<Response> AddOrder(OrderPostModel model)
        {
            Response response = new Response();
            try
            {
                

                #region Order
                double totalPrice = 0;

                //Checking if Product is Available or Not
                foreach (var item in model.productList)
                {
                    Product objProduct = await _db.products.FindAsync(item.ProductId);
                    if (objProduct == null)
                    {
                        response.Status = "500 Error";
                        response.Message = "Product Not Found";
                        return response;
                    }
                    else if (objProduct != null)
                    {
                        if (item.Quantity < 0 || item.Quantity > objProduct.Quantity || objProduct.IsActive == false)
                        {
                            response.Status = "501 Error";
                            response.Message = "Quantity Error OR Product is not Active" + objProduct.Quantity;
                            return response;
                        }
                        else
                        {
                            totalPrice = totalPrice + (item.Quantity * objProduct.Price);
                        }
                    }
                }

                //Creating Order  of Guest User
                Order objOrder = new Order()
                {
                    OrderDate = DateTime.Today,
                    Note = model.Note,
                    DisountAmount = 20,
                    StatusType = OrderStatus.Draft,
                    TotalAmount = totalPrice,
                    CustomerName = model.CustomerName,
                    CustomerEmail = model.CustomerEmail,
                    CustomerContactNo = model.CustomerContactNo,
                    IsActive = true,
                };

                var orderResult = await _db.orders.AddAsync(objOrder);
                _db.SaveChanges();

                //Adding products to list if order is created.
                if (orderResult != null)
                {
                    var orderData = _db.orders.Where(x => x.CustomerName == model.CustomerName).FirstOrDefault();
                    if (orderData != null)
                    {
                        var id = orderData.OrderId;

                        foreach (var item in model.productList)
                        {
                            Product objProduct = await _db.products.FindAsync(item.ProductId);
                            OrderItem objOrderItem = new OrderItem()
                            {
                                OrderID = objOrder.OrderId,
                                ProductId = item.ProductId,
                                Price = objProduct.Price,
                                Quantity = item.Quantity,
                                IsActive = objProduct.IsActive,
                            };
                            var orderItemResult = await _db.orderItems.AddAsync(objOrderItem);
                        }
                        _db.SaveChanges();

                    }
                }
                #endregion


                //Adding Address of Guest User
                #region Shipping Address

                Address objAddress = new Address()
                {
                    AddressType = AddressTypes.Shipping,
                    BuildingOrFlatNo = model.ShippingAddress.BuildingOrFlatNo,
                    Country = model.ShippingAddress.Country,
                    State = model.ShippingAddress.State,
                    City = model.ShippingAddress.City,
                    ZipCode = model.ShippingAddress.ZipCode,
                    ContactPerson = model.ShippingAddress.ContactPerson,
                    ContactNo = model.ShippingAddress.ContactNo,
                    Email = model.ShippingAddress.Email,
                    UserId = ""
                };

                _db.addressestwo.Add(objAddress);



                #endregion

                #region Billing Address

                Address objBillingAddress = new Address()
                {
                    AddressType = AddressTypes.Billing,
                    BuildingOrFlatNo = model.BillingAddress.BuildingOrFlatNo,
                    Country = model.BillingAddress.Country,
                    State = model.BillingAddress.State,
                    City = model.BillingAddress.City,
                    ZipCode = model.BillingAddress.ZipCode,
                    ContactPerson = model.BillingAddress.ContactPerson,
                    ContactNo = model.BillingAddress.ContactNo,
                    Email = model.BillingAddress.Email,
                    UserId = ""
                };
                _db.addressestwo.Add(objBillingAddress);

                _db.SaveChanges();

                #endregion


                var orderInfo = _db.orders.Where(x => x.CustomerEmail == model.CustomerEmail).FirstOrDefault();
                var billingInfo = _db.addressestwo.Where(y => y.Email == model.BillingAddress.Email && y.AddressType == AddressTypes.Billing).FirstOrDefault();
                var shippingInfo = _db.addressestwo.Where(z => z.Email == model.ShippingAddress.Email && z.AddressType == AddressTypes.Shipping).FirstOrDefault();

                OrderAddress orderAddress = new OrderAddress()
                {
                    OrderId = orderInfo.OrderId,
                    ShippingAddress = billingInfo.AddressId,
                    BillingAddress = shippingInfo.AddressId,
                };

                _db.orderaddress.Add(orderAddress);

                _db.SaveChanges();

                response.Status = "200 Ok";
                response.Message = "Order Added Successfully";
                return response;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            response.Status = "500 Bad";
            response.Message = "Something went wrong";
            return response;

        } 
        #endregion

        public async Task<Response> Get(OrderSearchModel model)
        {
            Response response = new Response();

            try
            {
                if(model.DateFrom == null && model.DateTo == null)
                {
                    var objOrder = await _db.orders.Where(x => x.OrderDate == model.DateFrom).FirstOrDefaultAsync();
                    if(objOrder != null)
                    {

                    }
                }
                else if(model.Email != null)
                {
                    var objOrder = await _db.orders.Where(x => x.CustomerEmail == model.Email).FirstOrDefaultAsync();
                    if(objOrder != null)
                    {
                        var totitems = _db.orderItems.Where(x => x.OrderID == objOrder.OrderId).Count();
                        var shippingAddress = _db.orderaddress.Where(y => y.OrderId == objOrder.OrderId);
                        response.Data = totitems;
                    }
                    
                    
                    return response;
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return response;
        }

        #region Update Order Status
        public async Task<Response> UpdateOrderStatus(int orderId, int StatusId)
        {
            Response response = new Response();

            if (orderId > 0 && StatusId > 0 && StatusId < 5)
            {
                var orderData = _db.orders.Where(x => x.OrderId == orderId).FirstOrDefault();
                if (orderData != null)
                {
                    if ((int)orderData.StatusType == 3)
                    {
                        response.Status = "501 Error";
                        response.Message = "You cannot Update Status Now.";
                        return response;
                    }
                    if ((int)orderData.StatusType == 2 && StatusId == (int)OrderStatus.Paid)
                    {
                        orderData.StatusType = OrderStatus.Paid;
                        orderData.IsActive = true;
                        _db.orders.Update(orderData);
                        _db.SaveChanges();
                        response.Status = "200 Ok";
                        response.Message = "Status Updated.";
                        return response;
                    }


                    if ((int)orderData.StatusType == 1 && StatusId.Equals(4) || StatusId.Equals(2) || StatusId.Equals(3))
                    {
                        orderData.StatusType = (OrderStatus)StatusId;
                        _db.orders.Update(orderData);
                        _db.SaveChanges();
                        response.Status = "200 Ok";
                        response.Message = "Status Updated.";
                        return response;
                    }
                    response.Status = "501 Bad";
                    response.Message = "Wrong Status Type Entered. (Open=1,Draft=2,Shipped=3,Paid=4)";
                    return response;
                }
                response.Status = "501 Bad";
                response.Message = "Order Not Found";
                return response;
            }
            response.Status = "501 Bad";
            response.Message = "Order_Id must be greater than 0";
            return response;
        } 
        #endregion
    }
}
