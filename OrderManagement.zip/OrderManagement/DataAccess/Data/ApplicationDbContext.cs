﻿using DataModels.Authentication;
using DataModels.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;


namespace DataAccess.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        }
        public DbSet<Order> orders { get; set; }
        public DbSet<Product> products { get; set; }
        public DbSet<Address> addressestwo { get; set; }
        public DbSet<OrderAddress> orderaddress { get; set; }
        public DbSet<User> aspnetusers { get; set; }
        public DbSet<OrderItem> orderItems { get; set; }
    }
}
