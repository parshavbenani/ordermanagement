﻿using DataModels.ViewModels;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModels.Models.GetModel
{
    public class AddressGetModel
    {
       public int AddressType { get; set; }
        [Required]
        public int BuildingOrFlatNo { get; set; }
        [Required]
        public string Country { get; set; }
        [Required]
        public string State { get; set; }
        [Required]
        public string City { get; set; }
        [Required]
        public int ZipCode { get; set; }
        [Required]
        public string ContactPerson { get; set; }
        [Phone]
        public string ContactNo { get; set; }
        [EmailAddress]
        [Required]
        public string Email { get; set; }
        public string? UserId { get; set; }
    }
}
