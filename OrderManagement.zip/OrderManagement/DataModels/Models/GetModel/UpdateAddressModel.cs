﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static DataModels.ViewModels.Constants;

namespace DataModels.Models.GetModel
{
    public class UpdateAddressModel
    {
        [Required]
        public int OrderAddressId { get; set; }
        [Required]
        public AddressTypes AddressType { get; set; }
        [Required]
        public AddressGetModel Address { get; set; }
    }
}
