﻿using static DataModels.ViewModels.Constants;

namespace DataModels.Models.GetModel
{
    public class OrderSearchModel
    {
        public DateTime? DateFrom { get; set; }
        public DateTime? DateTo { get; set; }
        public string? Email { get; set; }
        public bool? IsActive { get; set; }
        public OrderStatus? Status { get; set; }
        public int? ProductId { get; set; }


    }
}
