﻿using DataModels.Models;
using DataModels.Models.GetModel;
using DataModels.ViewModels;
using System.ComponentModel.DataAnnotations;

namespace Models.Models.GetModel
{
    public class OrderPostModel
    {
        public string Note { get; set; }
        [Required]
        public string CustomerName { get; set; }
        [EmailAddress]
        [Required]
        public string CustomerEmail { get; set; }
        [Required]
        [Phone]
        public string CustomerContactNo { get; set; }
        public List<ProductGet> productList { get; set; }
        [Required]
        public AddressGetModel BillingAddress { get; set; }
        [Required]
        public AddressGetModel ShippingAddress { get; set; }

    }
}
