﻿namespace Models.Models.GetModel
{
    public class OrderFilter
    {
        //[JsonIgnore]
        public DateTime? Date { get; set; }
        //public DateOnly? DateTo { get; set; }
        public int? StatusType { get; set; }
        public string? NameOrEmail { get; set; }
    }
}
