﻿using System.ComponentModel.DataAnnotations;

namespace DataModels.Models
{
    public class Category
    {
        [Key]
        public int CategoryID { get; set; }
        [Required]
        public string CategoryName { get; set; }
    }
}
