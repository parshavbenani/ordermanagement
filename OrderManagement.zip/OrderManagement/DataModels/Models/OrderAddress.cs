﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataModels.Models
{
    public class OrderAddress
    {
        [Key]
        public int OrderAddId { get; set; }
        [ForeignKey("OrderId")]
        [Required]
        public int OrderId { get; set; }
        [ForeignKey("AddressId")]
        [Required]
        public int ShippingAddress { get; set; }
        [Required]
        [ForeignKey("AddressId")]
        public int BillingAddress { get; set; }
    }
}
