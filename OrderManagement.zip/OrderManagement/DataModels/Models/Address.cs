﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataModels.ViewModels;

namespace DataModels.Models
{
    public class Address
    {
        [Key]
        public int AddressId { get; set; }
        public Constants.AddressTypes AddressType { get; set; }
        [Required]
        public int BuildingOrFlatNo { get; set; }
        [Required]
        public string Country { get; set; }
        [Required]
        public string State { get; set; }
        [Required]
        public string City { get; set; }
        [Required]
        public int ZipCode { get; set; }
        [Required]
        public string ContactPerson { get; set; }
        [Phone]
        [Required]
        public string ContactNo { get; set; }
        [EmailAddress]
        [Required]
        public string Email { get; set; }
        [ForeignKey("aspnetusers")]
        public string UserId { get; set; }
    }
}
