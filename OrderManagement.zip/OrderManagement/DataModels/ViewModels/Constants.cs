﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModels.ViewModels
{
    public class Constants
    {
        public enum OrderStatus
        {
            Open = 1,
            Shipped = 2,
            Paid = 3,
            Draft = 4
        }
        public enum AddressTypes
        {
            Shipping = 1,
            Billing = 2
        }
    }
}
