﻿using System.ComponentModel.DataAnnotations;

namespace DataModels.ViewModels
{
    public class ProductGet
    {
        [Required]
        public int ProductId { get; set; }
        [Required]
        public int Quantity { get; set; }
    }
}
