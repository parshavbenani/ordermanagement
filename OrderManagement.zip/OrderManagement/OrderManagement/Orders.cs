using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using DataModels.Models.GetModel;
using DataAccess.Repository.IRepository;
using DataModels.Models;
using Models.Models.GetModel;

namespace OrderManagement
{
   
    public  class Orders
    {
        private IAddressRepository _address;
        private IOrderRepository _orders;
        public Orders(IAddressRepository address,IOrderRepository orders)
        {
            _address = address;
            _orders = orders;
        }
        
        [FunctionName("AddAddress")]
        public  async Task<Response> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            AddressGetModel model = new AddressGetModel();
            log.LogInformation("Function Executed");

            var addressData = await new StreamReader(req.Body).ReadToEndAsync();
            model = JsonConvert.DeserializeObject<AddressGetModel>(addressData);

            return await _address.AddAddress(model);
        }

        
        [FunctionName("SearchOrder")]
        public async Task<Response> SearchOrder(
            [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            OrderSearchModel model = new OrderSearchModel();
            log.LogInformation("Function Executed");

            var searchData = await new StreamReader(req.Body).ReadToEndAsync();
            model = JsonConvert.DeserializeObject<OrderSearchModel>(searchData);

            return await _orders.Get(model);
        }
        
        
        [FunctionName("UpdateStatus")]
        public async Task<Response> UpdateStatus(
            [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = null)] HttpRequest req,
            ILogger log)
        {

            log.LogInformation("Function Executed");

            int orderId = int.Parse(req.Query["orderId"]);
            int status = int.Parse(req.Query["status"]);


            

            return await _orders.UpdateOrderStatus(orderId, status);
        }
        
        
        [FunctionName("CreateDraftOrder")]
        public async Task<Response> CreateDraftOrder(
            [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            OrderPostModel model = new OrderPostModel();
            log.LogInformation("Function Executed");

            var searchData = await new StreamReader(req.Body).ReadToEndAsync();
            model = JsonConvert.DeserializeObject<OrderPostModel>(searchData);

            return await _orders.AddOrder(model);
        }
        
        
        [FunctionName("UpdateOrderAddress")]
        public async Task<Response> UpdateOrderAddress(
            [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            UpdateAddressModel model = new UpdateAddressModel();
            log.LogInformation("Function Executed");

            var searchData = await new StreamReader(req.Body).ReadToEndAsync();
            model = JsonConvert.DeserializeObject<UpdateAddressModel>(searchData);

            return await _address.UpdateAddress(model);
        }

        [FunctionName("GetAddressList")]
        public async Task<Response> GetAddressList(
            [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            
            log.LogInformation("Function Executed");
            
            string getEmail = req.Query["email"];
            //var email = await new StreamReader(req.Body).ReadToEndAsync();
            //model = JsonConvert.DeserializeObject<OrderSearchModel>(searchData);

            return await _address.GetAddressList(getEmail);
        }


    }
}
